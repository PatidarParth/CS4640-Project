
import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class jdbcExample
 */
@WebServlet("/dbExample")
public class dB extends HttpServlet 
{
   private static final long serialVersionUID = 1L;
   // JDBC driver name and database URL
   final static String JDBC_DRIVER = "com.mysql.jdbc.Driver";  

   // database name = web4640
   //   Note: Looking in the wrong database and/or wrong table may results in either 
   //         cannot connect to the database, not find table, or no result set. 
   //         Thus, make sure specify the correct database name
   // post to mySQL Database = 3308  (default port in XAMPP is 3306)
   final static String DB_URL = "jdbc:mysql://localhost:3306/4640project";    
   
   //  Database credentials
   final static String USER = "4640";
   final static String PWD = "1234";
      
// Create a new user account "web4640" -- don't touch "root" account
// edit privileges, change password tab, assign password to the user ("pwd4640")
// be sure to refresh under title phpmyadmin at top-left corner   
   
   String msg = "";
   
//   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
//   {
//      response.setContentType("text/html");
//      PrintWriter out = response.getWriter();
//
//      String title = "Simple example: Servlet and Database";
//      out.println("<html>\n" + 
//                  "<head><title>" + title + "</title></head>\n" +
//    		      "<body>\n" + 
//                  "  <h1 align=\"center\">" + title + "</h1>\n");
//      out.println("  <center>");
//      out.println("  <form  method=\"post\">");      
//      out.println("     <button type=\"submit\" name=\"btn\" value=\"create\" />Create table</button>");
//      out.println("     <button type=\"submit\" name=\"btn\" value=\"insert\" />Insert data</button>");
//      out.println("     <button type=\"submit\" name=\"btn\" value=\"select\" />Retrieve data</button>");
//      out.println("     <button type=\"submit\" name=\"btn\" value=\"update\" />Update data</button>");
//      out.println("     <button type=\"submit\" name=\"btn\" value=\"delete\" title=\"Caution: this is unrecoverable transaction!\" />Delete data</button>");
//      out.println("     <button type=\"submit\" name=\"btn\" value=\"drop\" title=\"Caution: this is unrecoverable transaction!\" />Drop table</button>");
//      out.println("  </form>");
//      out.println("  Confirmation : " + msg);
//      out.println("</body>");
//      out.println("</html>");    
//   }   

   
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   {	  
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      
      String username = request.getParameter("username");
      String to_email = request.getParameter("inputEmail");            
      String password = request.getParameter("password");            
      
      out.println(username);
      out.println(to_email);
      out.println(password);
      msg = insertData(username, to_email, password);
     
      response.sendRedirect("login.jsp");
     
   }
     
   
   
   private String insertData(String username, String email, String password) 
   {	  
      ResultSet rs = null;
      Statement stmt = null;
      Connection conn = null;
      
      String msg = "";      // feedback indicating whether the query is successful
      
      try 
      {
         // Register JDBC driver
         Class.forName(JDBC_DRIVER);
         // System.out.println("MySQL JDBC Driver Registered");
	          
         // Open a connection
         conn = DriverManager.getConnection(DB_URL, "4640", "1234");
         // System.out.println("Connection established");
         String $username = username;
         String $email = email;
         String $password = password;
         // Execute SQL query
         stmt = conn.createStatement();
         String query2 = "insert into my_table (test_id, test_desc) valueass ('id1', 'desc1');" ;
         String query = "insert into my_table (username, email, password) values ('" + $username + "', '" + $email + "', '" + $password + "');" ;
         System.out.println(query);
         System.out.println(query2);

         int row = stmt.executeUpdate(query);            
         if (row > 0)
            msg = "A record was inserted";        
         else
            msg = "Unable to insert the record";

         // if no key is specified when creating the table, duplicates are allowed
         // try insert the same values multiple times to see what would happen with/without key
         // but we'll not worry about that for now
                 
         // Clean-up environment
         if (rs != null)
            rs.close();         
         stmt.close();
         conn.close();
         // System.out.println("close database");
                
         Driver driver = null;
         java.sql.DriverManager.deregisterDriver(driver);         
         // System.out.println("deregister driver");
         
      } catch (SQLException se) {
         se.printStackTrace();       // handle errors for JDBC
      } catch (Exception e) {            
         e.printStackTrace();        // handle errors for Class.forName
      } finally {
          // finally block used to close resources
          try {
             if (stmt != null)
                stmt.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se2) {
     	 // nothing we can do
         	 
          }             
          try
          {
             if (conn != null)
                conn.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se) {
             se.printStackTrace();
          } // end finally try   
          
       } // end try

      return msg;
   }
   
        
   private String updateData() 
   {	  
      ResultSet rs = null;
      Statement stmt = null;
      Connection conn = null;
      
      String msg = "";      // feedback indicating whether the query is successful
      
      try 
      {
         // Register JDBC driver
         Class.forName(JDBC_DRIVER);
         // System.out.println("MySQL JDBC Driver Registered");
	          
         // Open a connection
         conn = DriverManager.getConnection(DB_URL, "4640", "1234");
         // System.out.println("Connection established");
	   
         // Execute SQL query
         stmt = conn.createStatement();
         String query = "UPDATE `my_table` SET `test_desc`='new_desc2' WHERE `test_id`='id1';" ;
         int row = stmt.executeUpdate(query);
         if (row > 0)
            msg = "A record was updated";
         else
            msg = "Unable to update the record";
                 
         // Clean-up environment
         if (rs != null)
            rs.close();         
         stmt.close();
         conn.close();
         // System.out.println("close database");
                
         Driver driver = null;
         java.sql.DriverManager.deregisterDriver(driver);         
         // System.out.println("deregister driver");
         
      } catch (SQLException se) {
         se.printStackTrace();       // handle errors for JDBC
      } catch (Exception e) {            
         e.printStackTrace();        // handle errors for Class.forName
      } finally {
          // finally block used to close resources
          try {
             if (stmt != null)
                stmt.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se2) {
     	 // nothing we can do
         	 
          }             
          try
          {
             if (conn != null)
                conn.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se) {
             se.printStackTrace();
          } // end finally try   
          
       } // end try

      return msg;
   }

   private String deleteData() 
   {	  
      ResultSet rs = null;
      Statement stmt = null;
      Connection conn = null;
   
      String msg = "";      // feedback indicating whether the query is successful
   
      try 
      {
         // Register JDBC driver
         Class.forName(JDBC_DRIVER);
         // System.out.println("MySQL JDBC Driver Registered");
	             
         // Open a connection
         conn = DriverManager.getConnection(DB_URL, "4640", "1234");
         // System.out.println("Connection established");
	   
         // Execute SQL query
         stmt = conn.createStatement();
         String query = "DELETE FROM `my_table` WHERE test_id='id1';" ;
         int row = stmt.executeUpdate(query);     
         if (row > 0)
            msg = "A record was deleted";   
         else
            msg = "Unable to delete the record";
              
         // Clean-up environment
         if (rs != null)
            rs.close();         
         stmt.close();
         conn.close();
         // System.out.println("close database");
             
         Driver driver = null;
         java.sql.DriverManager.deregisterDriver(driver);         
         // System.out.println("deregister driver");
      
      } catch (SQLException se) {
         se.printStackTrace();       // handle errors for JDBC
      } catch (Exception e) {            
         e.printStackTrace();        // handle errors for Class.forName
      } finally {
          // finally block used to close resources
          try {
             if (stmt != null)
                stmt.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se2) {
        	 // nothing we can do
      	 
          }             
          try
          {
             if (conn != null)
                conn.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se) {
             se.printStackTrace();
          } // end finally try   
       
       } // end try

      return msg;
   }
   
   
   private String dropTable() 
   {	  
      ResultSet rs = null;
      Statement stmt = null;
      Connection conn = null;
      
      String msg = "";      // feedback indicating whether the query is successful
      
      try 
      {
         // Register JDBC driver
         Class.forName(JDBC_DRIVER);
         // System.out.println("MySQL JDBC Driver Registered");
	          
         // Open a connection
         conn = DriverManager.getConnection(DB_URL, "4640", "1234");
         // System.out.println("Connection established");
	   
         // Execute SQL query
         stmt = conn.createStatement();
         DatabaseMetaData dbm = conn.getMetaData();
         // check if the table is there
         ResultSet tables = dbm.getTables(null, null, "my_table", null);
         if (tables.next()) 
         {            
            String query = "drop table my_table;";
            int row = stmt.executeUpdate(query);
         // System.out.println("create row = " + row);      // this row will results in 0 because the query did not retrieve anything
            
            // check if the table was actually dropped
            // getTables("schema_name", null, "table_name", new String[] {"table"})   
            tables = dbm.getTables(null, null, "my_table", null);
            if (tables.next()) 
            {            
               // System.out.println("table was not dropped ");
               msg = "Table was dropped";
            }
            else
            {            
                // System.out.println("table was dropped ");
                msg = "Table was dropped";
            }            
         }

         // Clean-up environment
         if (rs != null)
            rs.close();         
         stmt.close();
         conn.close();
         // System.out.println("close database");
                
         Driver driver = null;
         java.sql.DriverManager.deregisterDriver(driver);         
         // System.out.println("deregister driver");
         
      } catch (SQLException se) {
         se.printStackTrace();       // handle errors for JDBC
      } catch (Exception e) {            
         e.printStackTrace();        // handle errors for Class.forName
      } finally {
          // finally block used to close resources
          try {
             if (stmt != null)
                stmt.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se2) {
     	 // nothing we can do
         	 
          }             
          try
          {
             if (conn != null)
                conn.close();

             Driver driver = null;
             java.sql.DriverManager.deregisterDriver(driver);

          } catch (SQLException se) {
             se.printStackTrace();
          } // end finally try   
          
       } // end try

      return msg;
   }

    
}